/*
 * File: 01211372697_Task1_1.cpp
 * Author: Youssif Khaled
 * Description: Print GRU.
 * Date: 13/8/2023
 */

/* Header Files */
#include <bits/stdc++.h>
using namespace std;

/* Main Function */
int main(){
    cout << "GRU" << endl;
    cout << "*****   ****    *    *" << endl;
    cout << "*       *   *   *    *" << endl;
    cout << "*  **   ****    *    *" << endl;
    cout << "*   *   *   *   *    *" << endl;
    cout << "*****   *    *  ******" << endl;
    return 0;
}