/*
 * File: 01211372697_Task1_3.cpp
 * Author: Youssif Khaled
 * Description: Mini Task Manager.
 * Date: 13/8/2023
 */

/* Header Files */
#include <bits/stdc++.h>
using namespace std;

// Struct to represent a task
struct task {
    bool status = false;  // Status of the task (completed or not)
    string name;  // Description of the task
    int ID;  // Unique identifier for the task
};

/* Main Function */
int main() {
    int option, uCmpnt = 0, x;
    vector<task> log;  // Vector to store the tasks
    task tmp;  // Temporary task structure

    while (true) {
        do {
            // Display menu options and get user input
            cout << "\n1. Add Task\n2. View Tasks\n3. Remove Task\n4. Update Task Status\n5. Exit\n";
            cout << "\nSelect an option: ";
            cin >> option;

            // Clear any error flags and ignore extra input
            if (cin.fail())
                cout << "Invalid option" << endl;
            cin.clear();
            cin.ignore(100, '\n');
        } while (cin.fail());

        switch (option) {
            case 1:
                // Add a new task
                cout << "\nEnter task description: ";
                cin >> tmp.name;
                tmp.ID = log.size() + 1;  // Assign a unique ID to the task
                log.push_back(tmp);  // Add the task to the vector
                uCmpnt++;  // Increment the uncompleted tasks counter
                cout << "Task added successfully!" << endl;
                break;
            case 2:
                // View the list of tasks
                if(log.size()==0){
                    cout << "My List is empty!" << endl;
                    continue;
                }
                cout << "\nCurrent Tasks:";
                for (int i = 0; i < log.size(); i++) {
                    cout << "\nTask ID: " << log[i].ID << endl;
                    cout << "Description: " << log[i].name << endl;
                    cout << "Status: ";
                    if (log[i].status)
                        cout << "Completed" << endl;
                    else
                        cout << "UnCompleted" << endl;
                }
                break;
            case 3:
                // Remove a task by its ID
                cout << "\nEnter task ID to remove: ";
                cin >> x;
                if (x <= log.size() && !cin.fail()) {
                    if (!log[x - 1].status)
                        uCmpnt--;  // Decrement uncompleted tasks counter if the task was uncompleted
                    log.erase(log.begin() + x - 1);  // Remove the task from the vector
                    for (int i = x-1; i < log.size(); i++)
                        log[i].ID--;  // Adjust the IDs of remaining tasks
                    cout << "Task removed successfully!\n";
                } else {
                    cout << "This task isn't on my list" << endl;
                    cin.clear();
                    cin.ignore(100, '\n');
                }
                break;
            case 4:
                if (!uCmpnt) {
                    cout << "All tasks are completed :)";
                    break;
                }
                // Update the status of a task to completed
                cout << "\nChoose a Task to check off:";
                for (int i = 0; i < log.size(); i++) {
                    if (!log[i].status) {
                        cout << "\nTask ID: " << log[i].ID << endl;
                        cout << "Description: " << log[i].name << endl;
                    }
                }
                cin >> x;
                if (!log[x - 1].status && !cin.fail()) {
                    log[x - 1].status = true;  // Mark the task as completed
                    uCmpnt--;  // Decrement uncompleted tasks counter
                    cout << "TASK(" << x << ") is checked off!" << endl;
                } else {
                    cout << "This task isn't on my list" << endl;
                    cin.clear();
                    cin.ignore(100, '\n');
                }
                break;
            case 5:
                cout << "Exiting Minions Task Manager. Have a great day!";
                return 0;
                break;
            default:
                break;
        }
    }
    return 0;
}