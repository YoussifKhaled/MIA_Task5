/*
 * File: 01211372697_Task1_4.cpp
 * Author: Youssif Khaled
 * Description: Sensors' Fusion.
 * Date: 13/8/2023
 */

/* Header Files */
#include <bits/stdc++.h>
using namespace std;

// Function to print the arrays
void print(double arr[10]){
    cout << "{";
    for(int i=0; i<10; i++){
        if(i == 9){
            cout << arr[i] << "}";
            break;
        }
        cout << arr[i] << ", ";
    }
}

/* Main Function */
int main(){
    // Arrays representing sensor readings
    double mpu6050[10] = {0.0, 11.68, 18.95, 23.56, 25.72, 25.38, 22.65, 18.01, 10.14, -0.26};//acc=0.78
    double bno55[10] =   {0.0,  9.49, 16.36, 21.2 , 23.16, 22.8 , 19.5 , 14.85,  6.79, -2.69};//acc=0.92
    //double Prdct[10] = {0.0,  9.56, 16.67, 21.33, 23.54, 23.29, 20.59, 15.44,  7.84, -2.21};

    // Arrays to store different fusion results
    /*
     * fair is avg regardless of accuracies
     * good is weighted average
     * great gets the predicted values to the equation
     */
    double fair[10], good[10], great[10];
    // Array of predicted trajectory 
    double predicted[10];

    // projectile trajectory over time intervals =0.5
    double time = 0,velocity = 30,angle = 46*3.14159/180;
    for(int i = 0; i < 10; i++){
        predicted[i] = velocity*sin(angle)*time-9.81*time*time/2;
        time += 0.5;
    }
    
    // Perform sensor fusion calculations for "fair" and "good" and "great" results
    for(int i = 0; i < 10; i++){
        fair[i] = (bno55[i] + mpu6050[i]) / 2; // Simple average fusion
        good[i] = (0.92 * bno55[i] + 0.78 * mpu6050[i]) / 1.7; // Weighted fusion
        //both sensors have avg acc = 0.85, prediction have that of 1, so trust factor was calculated as 0.85/1.85
        great[i] = predicted[i]+0.45945*(good[i]-predicted[i]); 
    }

    // Print the fusion results
    cout << "fair: "; print(fair); cout << endl;
    cout << "good: "; print(good); cout << endl;
    cout << "great: "; print(great); cout << endl;
    
    return 0;
}