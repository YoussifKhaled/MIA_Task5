/*
 * File: 01211372697_Task1_2.cpp
 * Author: Youssif Khaled
 * Description: Count Down.
 * Date: 13/8/2023
 */

/* Header Files */
#include <bits/stdc++.h>
# include <windows.h>
using namespace std;

/* Main Function*/
int main(){
    int start;
    cin >> start;
    for(int i=start;i>0;i--){
        cout << i << endl;
        Sleep(1000);
    }
    cout << "Blast off to the moon!";
    return 0;
}