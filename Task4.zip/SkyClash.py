import random

class Villain:
    def __init__(self, name, health=100, energy=500, shield=None):
        self.name = name
        self.health = health
        self.energy = energy
        self.shield = shield

    def take_damage(self, damage):
        if self.shield:
            reduction = self.shield.calculate_reduction()
            damage *= (1 - reduction)
        self.health -= damage
        if self.health < 0:
            self.health = 0

    def use_weapon(self, weapon, target):
        if self.energy >= weapon.energy_cost:
            self.energy -= weapon.energy_cost
            target.take_damage(weapon.damage)
            print(f"{self.name} attacks {target.name} with {weapon.name} for {weapon.damage} damage!")
        else:
            print(f"{self.name} doesn't have enough energy to use {weapon.name}!")

class Weapon:
    def __init__(self, name, energy_cost, damage):
        self.name = name
        self.energy_cost = energy_cost
        self.damage = damage

class Shield:
    def __init__(self, name, save_percentage):
        self.name = name
        self.save_percentage = save_percentage

    def calculate_reduction(self):
        return self.save_percentage / 100

# Define weapons
freeze_gun = Weapon("Freeze Gun", 50, 11)
electric_prod = Weapon("Electric Prod", 88, 18)
mega_magnet = Weapon("Mega Magnet", 92, 10)
kalman_missile = Weapon("Kalman Missile", 120, 20)
laser_blasters = Weapon("Laser Blasters", 40, 8)
plasma_grenades = Weapon("Plasma Grenades", 56, 13)
sonic_resonance_cannon = Weapon("Sonic Resonance Cannon", 100, 22)

# Define shields
energy_projected_barrier = Shield("Energy-Projected Barrier", 40)
selective_permeability = Shield("Selective Permeability", 90)
energy_net_trap = Shield("Energy Net Trap", 32)
quantum_deflector = Shield("Quantum Deflector", 80)

# Define villains
gru = Villain("Gru", shield=energy_projected_barrier)
vector = Villain("Vector", shield=quantum_deflector)

# Simulate rounds
rounds = 1
while gru.health > 0 and vector.health > 0:
    print(f"\nRound {rounds}")
    gru.use_weapon(electric_prod, vector)
    vector.use_weapon(plasma_grenades, gru)
    rounds += 1

# Determine the winner
winner = gru if gru.health > 0 else vector
print(f"\n{winner.name} wins the battle with {winner.health} health left!")